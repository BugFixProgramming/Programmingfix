package lithan.training.LithanSpringKYN.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lithan.training.LithanSpringKYN.daos.UserRepository;
import lithan.training.LithanSpringKYN.entities.User;
import lithan.training.LithanSpringKYN.services.StoreService;


@Controller
public class LoginController {
	
	@Autowired
	
	UserRepository userrepo;
	
	@Autowired
	StoreService service;
	
	
	  
	 
	@GetMapping("/home")
    public String postLogin(Model model) {
        String fname = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userrepo.findByUserName(fname);
        model.addAttribute("entities", user);
        return "index";
    }
	
	
	 
	 
	
	 @RequestMapping(value="/login",  method= RequestMethod.GET)
	    public String onLogin() {
	        return "login";
	    }

	    @RequestMapping(value="/login_error")
	    public String onLoginError(Model model) {
	        String error_msg = "Incorrect user or password. Please re-enter.";
	        model.addAttribute("error_string", error_msg);
	        return "login";
	    }
	    
	    @GetMapping("/profile")
	    public String postedit(Model model) {
	        String fname = SecurityContextHolder.getContext().getAuthentication().getName();
	        User user = userrepo.findByUserName(fname);
	        model.addAttribute("entities", user);
	        return "edit";
	    }
	    @GetMapping("/Update")
	    public String postupdate(Model model) {
	        String fname = SecurityContextHolder.getContext().getAuthentication().getName();
	        User user = userrepo.findByUserName(fname);
	        model.addAttribute("entities", user);
	        return "UpdateProfile";
	    }
	    @PostMapping("/result")
		 
		 public String postRegister(@ModelAttribute("entities") User user) {
		 service.addUser(user); return "edit";
		 
		 }
	    @RequestMapping("/delete")
		public String deleteStoreForm(@RequestParam int id) {
		storeService.delete(id);
		return "redirect:/";
		}
		@RequestMapping("/search")
		public ModelAndView search(@RequestParam String keyword) {
		List<Store> result = storeService.search(keyword);
		ModelAndView mav = new ModelAndView("search");
		mav.addObject("search", result);
		return mav;
		}
		
   }