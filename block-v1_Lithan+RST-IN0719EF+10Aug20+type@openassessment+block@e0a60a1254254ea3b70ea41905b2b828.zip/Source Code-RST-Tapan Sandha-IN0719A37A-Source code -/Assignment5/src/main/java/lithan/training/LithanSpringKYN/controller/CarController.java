package lithan.training.LithanSpringKYN.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sun.javafx.collections.MappingChange.Map;

import lithan.training.LithanSpringKYN.entities.Car;
import lithan.training.LithanSpringKYN.services.CarService;

public class CarController {
	
	@RequestMapping("/car")
	public String newCarPost(Map<String, Object> model) {
		Car car = new Car();
		((Object) model).put("car", car);
		return "carpost"; 
	}
	
	
	@PostMapping("/save")
	public String postform(@ModelAttribute("car") Car car) {
		CarService carservice = null;
		CarService.save(carservice);
		return "success";
	}

}
