package lithan.training.LithanSpringKYN.controller;


import lithan.training.LithanSpringKYN.daos.UserRepository;
import lithan.training.LithanSpringKYN.entities.Store;
import lithan.training.LithanSpringKYN.entities.User;
import lithan.training.LithanSpringKYN.services.StoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.List;

@Controller
public class StoreController {

    private static Logger logger = LoggerFactory.getLogger(StoreController.class);

    @Autowired
    UserRepository userrep;
    @Autowired
    private StoreService storeService;

    @RequestMapping(value="/",  method= RequestMethod.GET)
    public String handleRootRequest(Model model) {
        return "redirect:stores";
    }

    @RequestMapping(value="stores",  method= RequestMethod.GET)
    public String viewStores(Model model) {
        List<Store> stores = storeService.getAllStores();
        if(!CollectionUtils.isEmpty(stores)) {
            model.addAttribute("stores", stores);
        }
        return "home";
        
    }
    
	
}
	

