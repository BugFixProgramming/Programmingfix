package lithan.training.LithanSpringKYN.daos;

import lithan.training.LithanSpringKYN.entities.Store;
import lithan.training.LithanSpringKYN.entities.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StoreRepository extends JpaRepository<Store, Long> {
    Optional<Store> findByEmail(String email);

	void save(User user);

	

	
}
