package lithan.training.LithanSpringKYN.config;

import lithan.training.LithanSpringKYN.auth.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        return new UserDetailsServiceImpl();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    //Password Encoding is the process in which a password is converted from a literal text format into a humanly unreadable 
    //sequence of characters. If done correctly, it is very difficult to revert back to 
    //the original password and so it helps secure user credentials and prevent unauthorized access to a website.

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .formLogin()
                    .loginPage("/login")
                    .loginProcessingUrl("/login")
                    .failureUrl("/login_error")
                    .permitAll()
                    .defaultSuccessUrl("/home", true)
                .and()
                .csrf()
                .and()
                .authorizeRequests()
                
                .antMatchers(HttpMethod.GET, "/login").permitAll()
                   // .antMatchers(HttpMethod.GET, "/favicon.*").permitAll() 
                   // .antMatchers(HttpMethod.GET, "/role").hasRole("Admin")
                   // .antMatchers(HttpMethod.POST, "/stores").permitAll()
                  //  .antMatchers(HttpMethod.PUT, "/stores").permitAll()
                  //  .antMatchers(HttpMethod.DELETE, "/stores").permitAll()
                .and()
                .logout()
                    .logoutSuccessUrl("/login")
                    .invalidateHttpSession(true)
                    .deleteCookies("JSESSIONID");
    }
}
