package lithan.training.LithanSpringKYN.services;

import org.springframework.beans.factory.annotation.Autowired;

import lithan.training.LithanSpringKYN.daos.CarRepository;

public class CarService {
	
	
	@Autowired CarRepository repo;

public static void save(CarService carservice) {
	
}
	


}

