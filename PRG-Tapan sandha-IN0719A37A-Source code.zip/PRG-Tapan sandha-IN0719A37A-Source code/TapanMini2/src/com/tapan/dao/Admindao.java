package com.tapan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tapan.pojo.User;

public class Admindao {
	
public static Connection getConnection() throws Exception{
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registered");
			
			return DriverManager.getConnection("jdbc:mysql://projects.lithan.net/in0719a37a?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "IN0719A37A", "vart1DVV8");
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		return null;
	}
	
	public int register(String fname, String lname, String email, String phone, String address, String pword) throws Exception {
		
		int rows = 0;
		
		try {
			String sql = "insert into user (First_Name, Last_Name, Email, Phone, Address, Password) values(?,?,?,?,?,?)";
			 PreparedStatement stat = getConnection().prepareStatement(sql);
			 stat.setString(1, fname);
			 stat.setString(2, lname);
			 stat.setString(3, email);
			 stat.setString(4, phone);
			 stat.setString(5, address);
			 stat.setString(6, pword);
			 
			 rows = stat.executeUpdate();
			 return rows;
		}
		
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
		finally {
			if(getConnection()!=null) {
				getConnection().close();
			}
		}
		return rows;
	}
	
	public static User login (String email, String pword) throws Exception{
		User user = null;
		
		try {
			String sqls = "SELECT * from user where Email =? and Password = ?";
			
			PreparedStatement ps = getConnection().prepareStatement(sqls);
			ps.setString(1, email);
			ps.setString(2, pword);
			ResultSet rs = ps.executeQuery();
		    
			if(rs.next()) {
				user = new User();
				user.setFname(rs.getString(2));
				user.setLname(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setPhone(rs.getString(5));
				user.setAddress(rs.getString(6));
				user.setPword(rs.getString(7));
			}
			else {
				return null;
			}
		}
		catch(SQLException e)
		{
		e.printStackTrace();		
		}
		
		return user;
	}
	
	public static User fetchUserdetails(String email) throws SQLException, Exception {
		
		ResultSet rs = null;
		User user = null;
		
		try {
			
			String sql = "SELECT * FROM user WHERE Email=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, email);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				user = new User();
				user.setFname(rs.getString(2));
				user.setLname(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setPhone(rs.getString(5));
				user.setAddress(rs.getString(6));
				user.setPword(rs.getString(7));
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
		return user;

	}
	
	public int updatedetails(String fname, String lname, String email, String phone, String address) throws SQLException, Exception {
		
		getConnection().setAutoCommit(false);
		int rows = 0;
		
		try {
			String sql = "UPDATE user SET First_Name=?, Last_Name=?, Phone=?, Address=? WHERE Email=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, phone);
			ps.setString(4, address);
			ps.setString(5, email);
			rows = ps.executeUpdate();
			return rows;
		} 
		catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		finally{
			if(getConnection()!=null){
				getConnection().close();
			}
		}
		
	}
	
	public ResultSet gmail(String email) throws Exception {
		
		ResultSet rs = null;
		String sqls = "SELECT * from user where Email = ?";
		try {
			PreparedStatement ps = getConnection().prepareStatement(sqls);
			ps.setString(1, email);
			rs = ps.executeQuery();
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
		return rs;
	}
	
	public ResultSet searchdetails(String alist) throws SQLException, Exception {
		
		ResultSet rs = null;
		
		try {
			
			String sql = "SELECT * FROM user WHERE First_Name LIKE ? or Last_Name LIKE ? or Email LIKE ?";
			
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, alist);
			ps.setString(2, alist);
			ps.setString(3, alist);
			rs = ps.executeQuery();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
		
		return rs;
	
	}
	
	public int delete(String email) throws SQLException, Exception{
		
		int rows = 0;
		
		try {
		
			String sql = "DELETE FROM user WHERE Email=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, email);
			rows = ps.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(getConnection()!=null) {
				getConnection().close();
			}
		}
		
		return rows;
		
	}
}
