package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class ProfileAction extends ActionSupport {
	
	private static final long serialVersionUID = 6210448457936745149L;
	
	private String email;
	User user = new User();

	public String execute() throws Exception {

		user = Admindao.fetchUserdetails(email);
		if (user !=null) {
			return "success";
		} else {
			return "error";
		}

	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
