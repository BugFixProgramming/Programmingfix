package com.tapan.action;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class SearchAction extends ActionSupport {

	private static final long serialVersionUID = 8561333027154769588L;
	
	ResultSet rs = null;
	
	private String search1;
	
	Admindao dao = new Admindao();
	
	ArrayList<User> beanlist = null;

	private boolean noData = false;
	
	User user = null;
	
	
	public String execute() throws Exception{
		
		if(search1!=null) {
			String alist = search1 + "%";
			rs = dao.searchdetails(alist);
			int i = 0;
				
				beanlist = new ArrayList<User>();
				if(rs!=null) {
					while(rs.next()) {
						user = new User();
						user.setFname(rs.getString("First_Name"));
						user.setLname(rs.getString("Last_Name"));
						user.setEmail(rs.getString("Email"));
						beanlist.add(user);
						i++;
					}
				}
		
		
			if (i==0) {
				noData = false;
			} 
			else {
				noData = true;
				System.out.println(" Search " + beanlist);
			}
		}
			
		return "searchlist";
			
	}

	public boolean isNoData() {
		return noData;
	}

	public void setNoData(boolean noData) {
		this.noData = noData;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public ArrayList<User> getBeanlist() {
		return beanlist;
	}

	public void setBeanlist(ArrayList<User> beanlist) {
		this.beanlist = beanlist;
	}

	public String getSearch1() {
		return search1;
	}

	public void setSearch1(String search1) {
		this.search1 = search1;
	}
}
