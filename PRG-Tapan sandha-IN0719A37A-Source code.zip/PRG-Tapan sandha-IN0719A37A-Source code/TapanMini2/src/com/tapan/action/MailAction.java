package com.tapan.action;

import java.sql.ResultSet;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class MailAction extends ActionSupport {
	
	private static final long serialVersionUID = 7098866518371745926L;
	
	private String email;
	private String password;
	User user = new User();
	ResultSet rs;
	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String execute() throws Exception {
		if (email != null) {
			Admindao dao = new Admindao();
			
			ResultSet check = dao.gmail(email);
			if (check.next()) {
				System.out.println("RecoveryEmail verified");
		String to = getEmail();
		System.out.println(getEmail());
		user.setPword(check.getString("Password"));
		System.out.println(user.getPword());
		Properties properties = new Properties();
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.port", "465"); 
		Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("tapanlithan@gmail.com", "tapan123456");
			}
		}); 
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress("tapanlithan@gmail.com"));
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject("ABC JOBS PORTAL!!");
			message.setText("Your password is " + user.getPword());
			Transport.send(message);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
			
		}
	} else{
		return "error";	
	}
		
	}
		return "success";


}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
