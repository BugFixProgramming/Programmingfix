package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class UpdateProAction extends ActionSupport {

	private static final long serialVersionUID = -4136519098831646446L;
	
	private String fname = "", lname = "", email = "", phone = "", address="";

	private User user;

	private String msg;
	Admindao dao = new Admindao();
	String submit = "test";
	
	int rows = 0;
	
	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}
	
	public String execute() throws Exception {

		try {
			if (submit.equals("updatedata")) {
				user=Admindao.fetchUserdetails(email.trim());
			} else {
				System.out.println("while update "+user);
						
				int rows = dao.updatedetails(user.getFname(), user.getLname(), user.getEmail(), user.getPhone(), user.getAddress());
				if (rows > 0) {
					msg = ("Record Updated Successfully!");
				} else {

					msg = ("Error");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "updated";
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
