package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class LoginAction extends ActionSupport {

	private static final long serialVersionUID = 132976799360203505L;
	
	private String email;
	private String pword;
	
	private User user;
	
	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPword() {
		return pword;
	}


	public void setPword(String pword) {
		this.pword = pword;
	}



	public String execute() throws Exception 
	{
		user = Admindao.login(user.getEmail(), user.getPword());
		
		if(user!= null)
		{
			System.out.println(user.getFname());
			return "success";
		}
		else {

			return "error";
		}
		
	}
}
