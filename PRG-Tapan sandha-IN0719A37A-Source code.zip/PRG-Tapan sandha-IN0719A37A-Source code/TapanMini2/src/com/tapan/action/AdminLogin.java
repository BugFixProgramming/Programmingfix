package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;

public class AdminLogin extends ActionSupport {

	private static final long serialVersionUID = -2037204933139878196L;
	
	private String ademail;
	private String adpword;

	
	public String execute() throws Exception{
	
	if(getAdemail().equals("tapanlithan@gmail.com") && getAdpword().equals("tapan123456")) {
		return "success";
		}else {
		return "error";
		}
	}


	public String getAdemail() {
		return ademail;
	}


	public void setAdemail(String ademail) {
		this.ademail = ademail;
	}


	public String getAdpword() {
		return adpword;
	}


	public void setAdpword(String adpword) {
		this.adpword = adpword;
	}
	
	
}
