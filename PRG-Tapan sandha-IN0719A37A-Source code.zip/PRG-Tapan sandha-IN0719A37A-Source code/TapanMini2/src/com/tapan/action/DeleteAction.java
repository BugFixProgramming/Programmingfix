package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;
import com.tapan.pojo.User;

public class DeleteAction extends ActionSupport {

	private static final long serialVersionUID = 8536776897512311990L;
	
	User user = new User();
	
	private String email, msg;
	
	Admindao dao = new Admindao();
	
	public String execute() throws Exception{
		
		try {
		
			int rows = dao.delete(email);
			
			if(rows > 0) {
				msg="Record Deleted Successfully";
				System.out.println("Deleted");
			}
			else {
				msg="Error";
				System.out.println("None");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "delete";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
