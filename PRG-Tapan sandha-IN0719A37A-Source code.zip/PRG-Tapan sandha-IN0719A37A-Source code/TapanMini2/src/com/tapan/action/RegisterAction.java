package com.tapan.action;

import com.opensymphony.xwork2.ActionSupport;
import com.tapan.dao.Admindao;

public class RegisterAction extends ActionSupport {

	private static final long serialVersionUID = 3565050044453891925L;

	private String fname, lname, email, phone, address, pword;
	
	Admindao dao = null;
	
	int i = 0;
	
	public String execute() throws Exception{
		
		dao = new Admindao();
		
		try {
			i = dao.register(fname, lname, email, phone, address, pword);
			if (i > 0) {
				return "success";
			}
			else {
				return "error";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "Register";
	}
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}


