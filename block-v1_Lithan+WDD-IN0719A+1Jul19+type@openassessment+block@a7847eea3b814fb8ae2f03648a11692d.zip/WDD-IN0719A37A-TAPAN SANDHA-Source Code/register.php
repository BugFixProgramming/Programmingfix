<?php

$con = $con=mysqli_connect("localhost","IN0719A37A","vart1DVV8","in0719a37a");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  if(isset($_POST['firstname']))$fname = $_POST['firstname'];
$lname= $_POST['lastname']; // Fetching Values from URL.
$email=$_POST['email'];
$password= sha1($_POST['password']); // Password Encryption, If you like you can also leave sha1.
// Check if e-mail address syntax is valid or not
//echo "INSERT INTO register('Firstname', 'Lastname', 'Email', 'Password') values ('$fname', '$lname', '$email', '$password')";
$email = filter_var($email, FILTER_SANITIZE_EMAIL); // Sanitizing email(Remove unexpected symbol like <,>,?,#,!, etc.)
$result = mysqli_query($con,"INSERT INTO `register`(`firstname`, `lastname`, `Email`, `Password`) VALUES ('$fname', '$lname', '$email', '$password')");

if($result){

 
}
echo '<div>Thank you .....'.$fname . '</div>';
mysqli_close ($con);
?>