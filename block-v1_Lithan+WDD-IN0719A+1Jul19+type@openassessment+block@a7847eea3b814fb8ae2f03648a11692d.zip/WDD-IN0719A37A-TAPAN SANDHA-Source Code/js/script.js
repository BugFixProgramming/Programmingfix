var default_content="";

$(document).ready(function(){
	checkURL();
	$('ul li a').click(function (e){
	checkURL(this.hash);
});

//filling in the default content
default_content = $('#pageContent').html();

setInterval("checkURL()",250);
});

var lasturl="";

function checkURL(hash)
{
	if(!hash) 
		hash=window.location.hash;
	
	if(hash != lasturl)
	{
		lasturl=hash;
		// FIX - if we've used the history buttons to return to the homepage,
		// fill the pageContent with the default_content
		if(hash=="")
			$('#pageContent').html(default_content);
		else
		{
			if(hash=="#products")
				loadProducts();
			else
				loadPage(hash);
		}
	}
}


function loadPage(url)
{
	url=url.replace('#page','');
	$('#loading').css('visibility','visible');
	$.ajax({
		type: "POST",
		url: "load_page.php",
		data: 'page='+url,
		dataType: "html",
		success: function(msg)
		{
			if(parseInt(msg)!=0)
			{
				$('#pageContent').html(msg);
				$('#loading').css('visibility','hidden');
			}
		}
	});
}

function loadProducts() 
{
	$('#loading').css('visibility','visible');
	var jsonURL = "products.json";
	$.getJSON(jsonURL, function (json)
	{
		var imgList= '<div style="width:100%;height:50px" ><select name="currencies" class="currencies" style="float:right; margin:10px" id="currencies" onchange="changeCurrency()"></select></div>';
		imgList +=  '<ul class=\"products\">';
		prices = json.products;
		
		$.each(json.products, function () 
		{
			imgList += '<li><img src= "' + this.imgPath + '"><h3>' + this.name + '</h3><span class="curSymbol" style="float:left">$</span><h2 class="price" >'+this.price+'</h2><button class="product_submit" pid="'+this.pid+'">View Details</button></li>';
		});
		imgList+='</ul>'
		
		$('#pageContent').html(imgList);
		$('.product_submit').click(function(){submitItem($(this))});
		$('#loading').css('visibility','hidden');
		
		function submitItem(item)
		{
			var siblings = item.siblings();
/*		   console.log($(siblings[1]).html());
		   console.log($(siblings[2]));*/
			var pname = $(siblings[1]).html();
			var pprice = $(siblings[2]).html()+" "+$(siblings[3]).html();
			var pid = $(item).attr("pid"); 
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					console.log(this.responseText);
					document.getElementById("backendmessage").innerHTML = this.responseText;
				}
			};
			//pid = $('.')
			xmlhttp.open("GET", "submitproduct.php?pname=" +pname+'&pprice='+pprice+'&pid='+pid, true);
			xmlhttp.send();
		}
		
			
		// Get data .
		$.getJSON( "currencies.json", function( data ) 
		{
		// Call a function to create HTML for all the products.
		generateCurrencyHTML(data);
		});
		
		function generateCurrencyHTML(data)
		{ 
			products = $('#currencies');
			data.forEach(function (item, index) 
			{ 
				// Populate currency select item data.
				products.append($('<option class="currencies__option" value="'+item.value+'" symbol="'+item.symbol+'" data-id="'+item.id+'">'+item.id+'</option>'));
			});
		}
	});
}