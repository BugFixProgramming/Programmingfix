<?php
    $pid = $_GET['pid'];
    $pname = $_GET['pname'];
    $pprice = $_GET['pprice'];

    if(isset($pid) && isset($pname) && isset($pprice)){
    echo '<h2>Product Id :'.$pid .'</h2>';
    echo '<h2>Product Name: '.$pname .'</h2>';
    echo '<h2>Product Price: '.$pprice .'</h2>';

    }	
?>